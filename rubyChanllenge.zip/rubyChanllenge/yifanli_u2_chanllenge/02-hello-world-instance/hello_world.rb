# Creator: yifanli
# Created: 2023.05.15
# Content: Instance Methods



class HelloWorld
  def initialize(name)
    @name = name
  end

  def hello(greeted_name = nil)
    if greeted_name.nil?
      "Hello, World. My name is #{@name}!"
    else
      "Hello, #{greeted_name}. My name is #{@name}!"
    end
  end
end

hello_world = HelloWorld.new('Wally')
puts hello_world.hello('Bob')
