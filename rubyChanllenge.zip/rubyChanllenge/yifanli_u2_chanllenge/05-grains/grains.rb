# Creator: yifanli
# Created: 2023.05.16
# Content: 05-Grains on a Chessboard 


class Grains
  # Each Square is a power of 2
  def self.square(n)
    raise ArgumentError, 'Invalid square' unless (1..64).include?(n)
    2**(n-1)
  end

  # Total is the sum of all squares
  def self.total
    total_grains = 0
    (1..64).each do |n| 
    total_grains += square(n)
  end
    total_grains
  end

end
