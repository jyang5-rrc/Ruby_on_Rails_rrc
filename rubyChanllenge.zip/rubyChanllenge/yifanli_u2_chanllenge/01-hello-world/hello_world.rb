# Creator: yifanli
# Created: 2023.05.15
# Content: Class Method


class HelloWorld
  def self.hello(name = nil)
    if name.nil?
      "Hello, World!"
    else
      "Hello, #{name}!"
    end
  end
end
