# Author:yifanli
# Date:2023.05.15
# Content: Leap


# the most difficult part is to understand the logic of leap year
# the logic is:
# A year that is divisible by 4 and not divisible by 100,
# or divisible by 400, is a leap year.

class Year
  def self.leap?(year)
    (year % 4 == 0 && year % 100 != 0) || year % 400 == 0
  end
end