# Creator: yifanli
# Created: 2023.05.16
# Content: Pangram Class and Method 
# Pangrams are often used as a tool to test the functionality of 
# fonts, keyboards, or software that deals with text. 

class Pangram
  def self.is_pangram?(str)
    str.downcase.scan(/[a-z]/).uniq.size == 26
  end
end















# other solutions2:

=begin
class Pangram
  def self.is_pangram?(str)
    # create an array of all the letters in the alphabet
    alphabet = ('a'..'z').to_a
    # create an array of all the letters in the string
    letters = str.downcase.scan(/[a-z]/)
    # check if the letters in the string are the same as the letters in the alphabet
    letters.uniq.sort == alphabet
  end
end
=end