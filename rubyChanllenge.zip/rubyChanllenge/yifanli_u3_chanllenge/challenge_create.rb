# Objective: Use ActiveRecord to create data in the database.
# Author: yifanli
# Date: 2023-05-23

# Create three new products using the three different ways to create new AR objects.

require_relative 'ar.rb'

# Method 1: Using create method
product1 = Product.create(name: "Soft Tofu", description: "5 kg pkg.", 
                         price: 7.20, stock_quantity: 33, category_id: 7)

# Method 2: Using new and save methods
product2 = Product.new
product2.name = "Medium Tofu"
product2.description = "8 kg pkg."
product2.price = 9.20
product2.stock_quantity = 20
product2.category_id = 7
product2.save

# Method 3: Using a block
product3 = Product.new do |p|
  p.name = "Firm Tofu"
  p.description = "10 kg pkg."
  p.price = 11.20
  p.stock_quantity = 10
  p.category_id = 7
end
product3.save


# Create a Product object that is missing some required columns.
# Attempt to save this product and print all the AR errors which are generated.

product4 = Product.new
product4.name = "Salted Tofu"
product4.price = 11.20
product4.category_id = 7
product4.save
puts product4.errors.full_messages
