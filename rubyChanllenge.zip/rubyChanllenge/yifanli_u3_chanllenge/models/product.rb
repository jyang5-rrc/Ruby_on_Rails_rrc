class Product < ActiveRecord::Base
  # This AR object is linked with the products table.

  # Columns in the products table:
  # - id: integer
  # - name: varchar
  # - description: varchar
  # - price: decimal
  # - stock_quantity: integer
  # - category_id: integer
  # - created_at: datetime
  # - updated_at: datetime
  
  validates :name, uniqueness: true, length: { minimum: 4 }
  validate :all_columns_filled_out

  private

  def all_columns_filled_out
    required_columns = self.class.column_names - ['id', 'created_at', 'updated_at', 'category_id']
    required_columns.each do |column|
      errors.add(column.to_sym, "must be filled out") if self[column].blank?
    end
  end

  # A product has a many to one relationship with a category.
  # The products table has a category_id foreign key.
  # In other words, a product belongs to a category.
  belongs_to :category
end


