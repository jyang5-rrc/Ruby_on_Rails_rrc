# Objective: Learn Faker Read 
# Author: yifanli
# Date: 2023-05-23

require_relative 'ar.rb'

# Find all the categories in the database
categories = Category.includes(:products).all

# Display all category names and their associated products (name and price) in a nicely formatted list.
categories.each do |category|
  puts "Category: #{category.name}"
  category.products.each do |product|
    puts "Product: #{product.name}, Price: #{product.price}"
  end

  puts "--------------------------------------"
end