# Objective: Learn Faker 
# Author: yifanli
# Date: 2023-05-23


require_relative 'ar.rb'
require 'faker'

# In a loop user Faker to generate 10 new categories. 

10.times do
  category = Category.new(name: Faker::Commerce.department)
  category.save


  # Generate 10 new products for each category
  10.times do
    product = Product.new(
      name: Faker::Commerce.product_name,
      description: Faker::Lorem.sentence,
      price: Faker::Commerce.price(range: 0..100),
      stock_quantity: Faker::Number.between(from: 0, to: 100)
    )
    product.save
  end
end