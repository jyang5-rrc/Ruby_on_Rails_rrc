# Objective: Use ActiveRecord to delete data from the database.
# Author: yifanli
# Date: 2023-05-23

require_relative 'ar.rb'

# Find one of the products you created in challenge_create.rb
# and delete it from the database.

product = Product.find_by(name: "Soft Tofu")
product.destroy
