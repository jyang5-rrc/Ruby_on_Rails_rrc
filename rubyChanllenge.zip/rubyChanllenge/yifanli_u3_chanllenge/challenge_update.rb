# Objective: Use ActiveRecord to update data in the database.
# Author: yifanli
# Date: 2023-05-23

require_relative 'ar.rb'

# Find all products with a stock quantity greater than 40.

products = Product.where("stock_quantity > 40")

# Add one to the stock quantity of each of these products
# and then save these changes to the database.

products.update_all("stock_quantity = stock_quantity + 1")

