# Objective: Use ActiveRecord to read data from the database.
# Author: yifanli
# Date: 2023-05-23

require_relative 'ar.rb'

# Use the Product class to find (any) product from the database.
product = Product.order("RANDOM()").take
# Inspect the Product object you have retrieved. 
puts product.inspect

# Based on the columns you find, can you determine if the products table has an association with any other tables? If so, what table?
# Yes, the products table has a category_id column, which means it has a many to one relationship with the categories table.

# Puts the total number of products
number_of_products = Product.count
puts "There are #{number_of_products} products in the products table."

# The names of all products above $10 with names that begin with the letter C.
products_required = Product.where("price > 10 AND name LIKE 'C%'")
puts "Product names above $10 starting with 'C': #{products_required.pluck(:name)}"

# Total number of products with a low stock quantity. (Low is defined as less than 5 in stock.)
low_stock_products = Product.where("stock_quantity < 5")
puts  "There are #{low_stock_products.count} products with low stock."


# Find the name of the category associated with one of the products you have found. 
# (Hint: You will need to use the association method you found in part 1.)

category_name = product.category.name
puts "Category name associated with the product: #{category_name}"

# Find a specific category and use it to build and persist a new product associated with this category.

category = Category.find_by(name: "Ikura")
new_product = category.products.build(name: "Ikura Sushi", 
                                      description: "2 pieces",
                                      price: 3.50, stock_quantity: 10)
new_product.save
puts "New product with the category created: #{new_product.inspect}"

# Find a specific category and then use it to locate all the associated products 
# over a certain price.

category = Category.find_by(name: "Ikura")
high_price_products = category.products.where("price > 10")
puts "High price products associated with the category: #{high_price_products.pluck(:name)}"