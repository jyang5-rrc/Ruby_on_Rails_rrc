# Course: WEBD-3011 Agile Full Stack Development with Ruby on Rails
# Author: Yifan Li
# Description: U1 - Challenge 1.2 - Hash and Array
# Date: 2023-05-07
# Version: 1.0.0


ghosts = [
  { name: "Inky", age: 4, loves: "reindeers", net_worth: 25 },
  { name: "Pinky", age: 5, loves: "garden tools", net_worth: 14 },
  { name: "Blinky", age: 7, loves: "ninjas", net_worth: 18.03 },
  { name: "Clyde", age: 6, loves: "yarn", net_worth: 0 }
]

=begin
old way
ghosts = [
  {:name => "Inky", :age => 4, :loves => "reindeers", :net_worth => 25},
  {:name => "Pinky", :age => 5, :loves => "garden tools", :net_worth => 14},
  {:name => "Blinky", :age => 7, :loves => "ninjas", :net_worth => 18.03},
  {:name => "Clyde", :age => 6, :loves => "yarn", :net_worth => 0}
]
=end 

ghosts.each do |ghost|
  ghost_info  = "#{ghost[:name]} is #{ghost[:age]} years old, "
  ghost_info += "loves #{ghost[:loves]} and "
  ghost_info += "has #{ghost[:net_worth]} dollars in the bank."
  puts ghost_info
end

