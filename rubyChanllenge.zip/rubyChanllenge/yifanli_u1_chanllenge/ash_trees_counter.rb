# Course: WEBD-3011 Agile Full Stack Development with Ruby on Rails
# Author: Yifan Li
# Description: U1 - Challenge 1.4 - JSON AND API Ash Trees
# Date: 2023-05-07
# Version: 1.0.0


# load the libraries
require 'net/http' 
require 'json' 
require 'pp' 

# URL for the ash trees data
url = 'https://data.winnipeg.ca/resource/d3jk-hb6j.json?$limit=306000'
uri = URI(url) 

# Convert string to URI object.
response = Net::HTTP.get(uri) 
ash_tree = JSON.parse(response) # Convert JSON data into Ruby data.
# pp ash_trees # pp stands for pretty print.

ash_tree_count = 0

ash_tree.each do |ash_tree|
  if ash_tree["common_name"].downcase.include?("ash")
    ash_tree_count += 1
  end
end

puts "There are #{ash_tree_count} ash trees in Winnipeg."


