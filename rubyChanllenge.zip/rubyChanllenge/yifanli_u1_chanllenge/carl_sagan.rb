# Course: WEBD-3011 Agile Full Stack Development with Ruby on Rails
# Author: Yifan Li
# Description: U1 - Challenge 1
# Date: 2023-05-07
# Version: 1.0.0



# 1.1  Carl Sagan 

carl  = {
  :toast => 'cosmos',
  :punctuation => [ ',', '.', '?' ],
  :words => [ 'know', 'for', 'we']
}

sagan = [
  { :are => 'are', 'A' => 'a' },
  { 'waaaaaay' => 'way', :th3 => 'the' },
  'itself',
  { 2 => ['to']}
]

# Here is an example of building a setence out of array/hash pieces.
example = [ 'test', 'a', 'is']
time    = { :that => 'This', :period => '.'}
puts "#{time[:that]} #{example[2]} #{example[1]} #{example[0]}#{time[:period]}"

words = carl[:words]
punctuation = carl[:punctuation]
are = sagan[0][:are]
a = sagan[0]['A']
way = sagan[1]['waaaaaay']
th3 = sagan[1][:th3]
cosmos = carl[:toast]
to = sagan[3][2][0]

sentence = "#{words[2].capitalize} #{are} #{a} #{way} #{words[1]} #{th3} #{cosmos} #{to} #{words[0]} #{sagan[2]}#{punctuation[1]}"
puts sentence



# 1.2 Ghosts

ghosts = [
  { name: "Inky", age: 4, loves: "reindeers", net_worth: 25 },
  { name: "Pinky", age: 5, loves: "garden tools", net_worth: 14 },
  { name: "Blinky", age: 7, loves: "ninjas", net_worth: 18.03 },
  { name: "Clyde", age: 6, loves: "yarn", net_worth: 0 }
]

ghosts.each do |ghost|
  ghost_info  = "#{ghost[:name]} is #{ghost[:age]} years old, "
  ghost_info += "loves #{ghost[:loves]} and "
  ghost_info += "has #{ghost[:net_worth]} dollars in the bank."
  puts ghost_info
end


# 1.3 Dog Breeds

require 'net/http' #loads the net/http library
require 'json' #loads the json library
require 'pp' #loads the pp library

url = 'https://dog.ceo/api/breeds/list/all'
uri = URI(url) # Convert string to URI object.
response = Net::HTTP.get(uri) 
dog_breeds = JSON.parse(response) # Convert JSON data into Ruby data.
# pp dog_breeds # pp stands for pretty print.

# each loop through the key and value of the hash
# key = breed name, value = sub_breeds array
dog_breeds["message"].each do |breed, sub_breeds|
  if sub_breeds.empty?
    puts "* #{breed.capitalize}"
  else 
    puts "* #{breed.capitalize}"
    sub_breeds.each do |sub_breed|
      puts "  * #{sub_breed.capitalize}"
    end
  end
end



# 1.4 Ash Trees

# load the libraries
require 'net/http' 
require 'json' 
require 'pp' 

# URL for the ash trees data
url = 'https://data.winnipeg.ca/resource/d3jk-hb6j.json?$limit=306000'
uri = URI(url) 

# Convert string to URI object.
response = Net::HTTP.get(uri) 
ash_tree = JSON.parse(response) # Convert JSON data into Ruby data.
# pp ash_trees # pp stands for pretty print.

ash_tree_count = 0

ash_tree.each do |ash_tree|
  if ash_tree["common_name"].downcase.include?("ash")
    ash_tree_count += 1
  end
end

puts "There are #{ash_tree_count} ash trees in Winnipeg."

