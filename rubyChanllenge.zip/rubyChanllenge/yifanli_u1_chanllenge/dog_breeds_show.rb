# Course: WEBD-3011 Agile Full Stack Development with Ruby on Rails
# Author: Yifan Li
# Description: U1 - Challenge 1.3 - JSON AND API 
# Date: 2023-05-07
# Version: 1.0.0


# 3) Write a script that uses the JSON provided by the dog.ceo API 
# to print out a nicely formatted list of dog breeds and sub-breeds. 

require 'net/http' #loads the net/http library
require 'json' #loads the json library
require 'pp' #loads the pp library

url = 'https://dog.ceo/api/breeds/list/all'
uri = URI(url) # Convert string to URI object.
response = Net::HTTP.get(uri) 
dog_breeds = JSON.parse(response) # Convert JSON data into Ruby data.
# pp dog_breeds # pp stands for pretty print.

# each loop through the key and value of the hash
# key = breed name, value = sub_breeds array
dog_breeds["message"].each do |breed, sub_breeds|
  if sub_breeds.empty?
    puts "* #{breed.capitalize}"
  else 
    puts "* #{breed.capitalize}"
    sub_breeds.each do |sub_breed|
      puts "  * #{sub_breed.capitalize}"
    end
  end
end
