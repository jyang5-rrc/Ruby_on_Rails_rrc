# Course: WEBD-3011 Agile Full Stack Development with Ruby on Rails
# Author: Yifan Li
# Description: U0 - Challenge Zero
# Date: 2023-05-07
# Version: 1.1

# 1) Calculates the after tax value of a specific dollar amount.

# Constants
GST_RATE = 0.05  #GST tax rate 5%
PST_RATE = 0.07 #PST tax rate 7%

# Get the subtotal from user
print "Please enter the subtotal (numbers only):"
# Get the input and donot worry about the trailing zeros
sub_total = gets.chomp.to_f 

# Calculate the tax and grand total
gst = (sub_total * GST_RATE)
pst = (sub_total * PST_RATE)
grand_total = sub_total + gst + pst

# Print the result
puts "Subtotal: $#{sub_total.round(2)}"
puts "GST: $#{gst.round(2)}"
puts "PST: $#{pst.round(2)}"
puts "Total: $#{grand_total.round(2)}"

# 2) Update your Ruby 
# program from question one such 
# that it prints a short message after the grand total.
# If the grand total is equal to or less than $5.00 then message should be: "Pocket Change"
# If the grand total is greater than $5.00 but less than $20 the message should be: "Wallet Time"
# If the grand total is equal to or greater than $20 the message should be: "Charge It!"


# Case statement is a good way to handle multiple conditions
case grand_total
  when 0..5
    message = "Pocket Change"
  when 5..20
    message = "Wallet Time"
  else
    message = "Charge It!"
end

# %.2f  %  is another way to round the number to 2 decimal places
puts "Grand Total: $#{'%.2f' % grand_total} - #{message}"


